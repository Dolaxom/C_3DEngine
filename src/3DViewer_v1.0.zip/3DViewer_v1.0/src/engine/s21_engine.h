#ifndef SRC_ENGINE_S21_ENGINE_H
#define SRC_ENGINE_S21_ENGINE_H

#include <stdlib.h>
#include <stdio.h>
#include "s21_mesh.h"

#endif  // SRC_ENGINE_S21_ENGINE_H